# yatube_project

### Социальная сеть блогеров
Благодаря этому сервису я сдам 3 спринт

### Технологии
python==3.9
Django==2.2.19
pytz==2022.7.1
sqlparse==0.4.3

### Запуск проекта в режиме разработчика
- Установите и активируйте виртуальное окружение:
'''
python -m venv venv

source venv/Scripts/activate 
'''

- Установите ПО из фаила requirements.txt: 
'''
pip install -r requiremetnts.txt
'''

- В папке с фаилом manage.py выполните команду:
'''
python manage.py runserver
'''
- И запустится сервер разработчика
### Авторы
Я