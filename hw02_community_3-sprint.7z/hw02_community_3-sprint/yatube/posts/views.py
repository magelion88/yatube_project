from django.shortcuts import render, get_object_or_404

from .models import Group, Post
'''
В этом фаиле обрабатываются запросы к страницам
'''
NUMBER_OF_POSTS_PER_PAGE = 10


def index(request):
    posts = Post.objects.all()[:NUMBER_OF_POSTS_PER_PAGE]
    context = {
        'title': 'Последние обновления на сайте',
        'posts': posts,
    }
    return render(request, 'posts/index.html', context)


def group_posts(request, slug):
    group = get_object_or_404(Group, slug=slug)
    posts = group.posts.all()[:NUMBER_OF_POSTS_PER_PAGE]
    context = {
        'title': 'Записи сообщества Лев Толстой–зеркало русской революции',
        'group': group,
        'posts': posts,
    }
    return render(request, 'posts/group_list.html', context)
